from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector

app = Flask(__name__)
CORS(app) # Allows frontend to make requests to this backend

# Database connection details (Update with your MySQL credentials)
db_config = {
    'host': 'localhost',
    'port': 3306,
    'user': 'root',
    'password': '6377', #  your MySQL password
    'database': 'vanshika_fashion',
    'use_pure': True
}

def get_db_connection():
    return mysql.connector.connect(**db_config)

@app.route('/api/suits', methods=['GET'])
def get_suits():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM suits WHERE in_stock > 0")
    suits = cursor.fetchall()
    conn.close()
    return jsonify(suits)

@app.route('/api/designs', methods=['GET'])
def get_designs():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM embroidery_designs WHERE is_available != 0")
    designs = cursor.fetchall()
    conn.close()
    return jsonify(designs)

@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        # Check if the requested design has pre-made stock ("bane huye")
        cursor.execute("SELECT pre_made_stock FROM embroidery_designs WHERE id = %s", (data['design_id'],))
        design = cursor.fetchone()
        
        is_pre_made = False
        status = 'Order Placed'

        if design['pre_made_stock'] > 0:
            is_pre_made = True
            status = 'Ready for Dispatch'
            # Deduct 1 from pre-made stock
            cursor.execute("UPDATE embroidery_designs SET pre_made_stock = pre_made_stock - 1 WHERE id = %s", (data['design_id'],))

        # Insert the new order
        insert_query = """
            INSERT INTO orders (customer_name, customer_phone, suit_id, design_id, is_pre_made, total_price, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(insert_query, (
            data['customer_name'], data['customer_phone'], 
            data['suit_id'], data['design_id'], 
            is_pre_made, data['total_price'], status
        ))
        
        conn.commit()
        return jsonify({"message": "Order created successfully", "order_id": cursor.lastrowid}), 201

    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()

@app.route('/api/orders/<int:order_id>', methods=['GET'])
def track_order(order_id):
    customer_phone = request.args.get('phone')

    if not customer_phone:
        return jsonify({"error": "Phone number is required"}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute(
            """
            SELECT
                orders.id,
                orders.customer_name,
                orders.customer_phone,
                orders.total_price,
                orders.status,
                orders.created_at,
                suits.name AS suit_name,
                embroidery_designs.design_name
            FROM orders
            JOIN suits ON orders.suit_id = suits.id
            JOIN embroidery_designs ON orders.design_id = embroidery_designs.id
            WHERE orders.id = %s AND orders.customer_phone = %s
            """,
            (order_id, customer_phone),
        )
        order = cursor.fetchone()

        if not order:
            return jsonify({"error": "Order not found"}), 404

        return jsonify(order)
    finally:
        conn.close()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
