import mysql.connector


DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "6377",
    "use_pure": True,
}

DATABASE_NAME = "vanshika_fashion"

SUITS = [
    ("Classic Kurta", "Cotton", 1500.00, 10),
    ("Designer Anarkali Suit", "Silk", 2500.00, 5),
    ("Punjabi Patiala Suit", "Cotton", 1800.00, 8),
    ("Wedding Sharara Suit", "Georgette", 4500.00, 3),
]

DESIGNS = [
    ("Royal Peacock Motif", 500.00, 2, True),
    ("Golden Zari Border", 700.00, 4, True),
    ("Floral Thread Work", 600.00, 0, True),
    ("Mirror Work Design", 900.00, 2, True),
]


def create_tables(cursor):
    cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DATABASE_NAME}")
    cursor.execute(f"USE {DATABASE_NAME}")

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS suits (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            fabric VARCHAR(100) NOT NULL,
            price DECIMAL(10, 2) NOT NULL,
            in_stock INT DEFAULT 0
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS embroidery_designs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            design_name VARCHAR(255) NOT NULL,
            additional_cost DECIMAL(10, 2) NOT NULL,
            pre_made_stock INT DEFAULT 0,
            is_available BOOLEAN DEFAULT TRUE
        )
        """
    )

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_name VARCHAR(255) NOT NULL,
            customer_phone VARCHAR(20) NOT NULL,
            suit_id INT NOT NULL,
            design_id INT NOT NULL,
            is_pre_made BOOLEAN DEFAULT FALSE,
            total_price DECIMAL(10, 2) NOT NULL,
            status VARCHAR(50) DEFAULT 'Order Placed',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (suit_id) REFERENCES suits(id),
            FOREIGN KEY (design_id) REFERENCES embroidery_designs(id)
        )
        """
    )


def row_exists(cursor, table, column, value):
    cursor.execute(f"SELECT id FROM {table} WHERE {column} = %s LIMIT 1", (value,))
    return cursor.fetchone() is not None


def seed_data(cursor):
    for suit in SUITS:
        if not row_exists(cursor, "suits", "name", suit[0]):
            cursor.execute(
                """
                INSERT INTO suits (name, fabric, price, in_stock)
                VALUES (%s, %s, %s, %s)
                """,
                suit,
            )

    for design in DESIGNS:
        if not row_exists(cursor, "embroidery_designs", "design_name", design[0]):
            cursor.execute(
                """
                INSERT INTO embroidery_designs
                    (design_name, additional_cost, pre_made_stock, is_available)
                VALUES (%s, %s, %s, %s)
                """,
                design,
            )


def print_counts(cursor):
    for table in ("suits", "embroidery_designs", "orders"):
        cursor.execute(f"SELECT COUNT(*) AS count FROM {table}")
        print(f"{table}: {cursor.fetchone()['count']} rows")


def main():
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor(dictionary=True)

    try:
        create_tables(cursor)
        seed_data(cursor)
        conn.commit()
        print("Database setup complete.")
        print_counts(cursor)
    finally:
        cursor.close()
        conn.close()


if __name__ == "__main__":
    main()
