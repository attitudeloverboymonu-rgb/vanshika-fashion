CREATE DATABASE vanshika_fashion;
USE vanshika_fashion;

-- Table for Base Suits
CREATE TABLE suits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    fabric VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    in_stock INT DEFAULT 0
);

-- Table for Embroidery Designs
CREATE TABLE embroidery_designs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    design_name VARCHAR(255) NOT NULL,
    additional_cost DECIMAL(10, 2) NOT NULL,
    pre_made_stock INT DEFAULT 0,  -- "kitane bane huye pade hai"
    is_available BOOLEAN DEFAULT TRUE
);

-- Table for Orders
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    suit_id INT NOT NULL,
    design_id INT NOT NULL,
    is_pre_made BOOLEAN DEFAULT FALSE,
    total_price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Order Placed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (suit_id) REFERENCES suits(id),
    FOREIGN KEY (design_id) REFERENCES embroidery_designs(id)
);

-- Insert some test data
INSERT INTO suits (name, fabric, price, in_stock) VALUES ('Classic Kurta', 'Cotton', 1500.00, 10);
INSERT INTO embroidery_designs (design_name, additional_cost, pre_made_stock) VALUES ('Royal Peacock Motif', 500.00, 2);