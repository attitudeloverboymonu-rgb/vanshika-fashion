const API_URL = 'http://localhost:5000/api';
let selectedSuit = null;
let selectedDesign = null;

const suitImages = {
    'classic kurta': 'Base Suit images/classic kurta.jfif',
    'designer anarkali suit': 'Base Suit images/anarkali suit.jfif',
    'anarkali suit': 'Base Suit images/anarkali suit.jfif',
    'punjabi patiala suit': 'Base Suit images/panjabi patiyala suit.jfif',
    'panjabi patiyala suit': 'Base Suit images/panjabi patiyala suit.jfif',
    'wedding sharara suit': 'Base Suit images/wedding sarara suit.jfif',
    'wedding sarara suit': 'Base Suit images/wedding sarara suit.jfif'
};

const designImages = {
    'royal peacock motif': 'Embroidery Design images/design1.jfif',
    'golden zari border': 'Embroidery Design images/design2.jfif',
    'floral thread work': 'Embroidery Design images/design3.jfif',
    'mirror work design': 'Embroidery Design images/design4.jfif'
};

const designImagesById = {
    1: 'Embroidery Design images/design1.jfif',
    2: 'Embroidery Design images/design2.jfif',
    3: 'Embroidery Design images/design3.jfif',
    4: 'Embroidery Design images/design4.jfif'
};

function normalizeName(name) {
    return String(name || '').trim().toLowerCase();
}

function getSuitImage(suit) {
    return suitImages[normalizeName(suit.name)] || 'Base Suit images/classic kurta.jfif';
}

function getDesignImage(design, index) {
    return designImages[normalizeName(design.design_name)] ||
        designImagesById[design.id] ||
        `Embroidery Design images/design${index + 1}.jfif`;
}

// Initialize App
document.addEventListener('DOMContentLoaded', loadSuits);

async function loadSuits() {
    try {
        const response = await fetch(`${API_URL}/suits`);
        const suits = await response.json();
        
        const grid = document.getElementById('suits-grid');
        grid.innerHTML = suits.map(suit => `
            <div class="card" onclick="selectSuit(${suit.id}, '${suit.name}', ${suit.price})">
                <img src="${getSuitImage(suit)}" alt="${suit.name}" class="card-img">
                <div class="card-content">
                    <h3>${suit.name}</h3>
                    <p class="card-fabric">Fabric: ${suit.fabric}</p>
                    <p class="card-price">₹${suit.price}</p>
                    <button class="btn-primary">Select Suit</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error("Error loading suits. Make sure backend is running.", error);
        document.getElementById('suits-grid').innerHTML = '<p>Could not load suits. Please start the Python backend.</p>';
    }
}

async function selectSuit(id, name, price) {
    selectedSuit = { id, name, price };
    
    // UI Transitions
    document.getElementById('hero-banner').classList.add('hidden');
    document.getElementById('step-1').classList.add('hidden');
    document.getElementById('step-2').classList.remove('hidden');
    document.getElementById('selected-suit-name').innerText = name;
    
    // Load designs
    try {
        const response = await fetch(`${API_URL}/designs`);
        if (!response.ok) {
            throw new Error('Designs API failed');
        }

        const designs = await response.json();
        
        const grid = document.getElementById('designs-grid');
        if (designs.length === 0) {
            grid.innerHTML = '<p>No embroidery designs are available right now.</p>';
            return;
        }

        grid.innerHTML = designs.map((d, index) => `
            <div class="card" onclick="selectDesign(${d.id}, '${d.design_name}', ${d.additional_cost})">
                <img src="${getDesignImage(d, index)}" alt="${d.design_name}" class="card-img">
                <div class="card-content">
                    ${d.pre_made_stock > 0 
                        ? `<span class="stock-badge stock-ready">Ready to Ship: ${d.pre_made_stock}</span>` 
                        : `<span class="stock-badge stock-made">Made to Order</span>`}
                    <h3>${d.design_name}</h3>
                    <p class="card-price">+ ₹${d.additional_cost}</p>
                    <button class="btn-primary">Add Design</button>
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error("Error loading designs.", error);
        document.getElementById('designs-grid').innerHTML = '<p>Could not load embroidery designs. Please make sure backend is running and database has available designs.</p>';
    }
}

function selectDesign(id, name, cost) {
    selectedDesign = { id, name, cost };
    
    // UI Transitions
    document.getElementById('step-2').classList.add('hidden');
    document.getElementById('step-3').classList.remove('hidden');

    // Update Summary
    document.getElementById('summary-suit').innerText = `Base Suit: ${selectedSuit.name} (₹${selectedSuit.price})`;
    document.getElementById('summary-design').innerText = `Embroidery: ${selectedDesign.name} (+₹${selectedDesign.cost})`;
    document.getElementById('summary-total').innerText = `Total: ₹${selectedSuit.price + selectedDesign.cost}`;
}

// Navigation Functions
function goBackToSuits() {
    document.getElementById('step-2').classList.add('hidden');
    document.getElementById('step-1').classList.remove('hidden');
    document.getElementById('hero-banner').classList.remove('hidden');
    selectedSuit = null;
}

function goBackToDesigns() {
    document.getElementById('step-3').classList.add('hidden');
    document.getElementById('step-2').classList.remove('hidden');
    selectedDesign = null;
}

function resetApp() {
    goBackToSuits();
    document.getElementById('step-3').classList.add('hidden');
    document.getElementById('track-order').classList.add('hidden');
}

function hideAllSections() {
    document.getElementById('hero-banner').classList.add('hidden');
    document.getElementById('step-1').classList.add('hidden');
    document.getElementById('step-2').classList.add('hidden');
    document.getElementById('step-3').classList.add('hidden');
    document.getElementById('track-order').classList.add('hidden');
}

function showTrackOrder() {
    hideAllSections();
    document.getElementById('track-order').classList.remove('hidden');
    document.getElementById('track-result').classList.add('hidden');
}

// Handle Order Submission
document.getElementById('order-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    submitBtn.innerText = 'Processing...';
    submitBtn.disabled = true;

    const orderData = {
        customer_name: document.getElementById('customer_name').value,
        customer_phone: document.getElementById('customer_phone').value,
        suit_id: selectedSuit.id,
        design_id: selectedDesign.id,
        total_price: selectedSuit.price + selectedDesign.cost
    };

    try {
        const response = await fetch(`${API_URL}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        
        if(response.ok) {
            const result = await response.json();
            alert(`Order placed successfully! Your Order ID is ${result.order_id}. Use this ID and phone number to track your order.`);
            window.location.reload(); 
        } else {
            alert('Error placing order. Please try again.');
            submitBtn.innerText = 'Confirm & Place Order';
            submitBtn.disabled = false;
        }
    } catch (error) {
        alert('Error communicating with the server. Ensure Python backend is running.');
        submitBtn.innerText = 'Confirm & Place Order';
        submitBtn.disabled = false;
    }
});

document.getElementById('track-order-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const orderId = document.getElementById('track_order_id').value;
    const phone = document.getElementById('track_phone').value;
    const resultBox = document.getElementById('track-result');

    resultBox.classList.remove('hidden');
    resultBox.innerHTML = '<p>Checking order status...</p>';

    try {
        const response = await fetch(`${API_URL}/orders/${orderId}?phone=${encodeURIComponent(phone)}`);
        const result = await response.json();

        if (!response.ok) {
            resultBox.innerHTML = `<p class="error-text">${result.error || 'Order not found.'}</p>`;
            return;
        }

        resultBox.innerHTML = `
            <h3>Order #${result.id}</h3>
            <p><strong>Name:</strong> ${result.customer_name}</p>
            <p><strong>Suit:</strong> ${result.suit_name}</p>
            <p><strong>Design:</strong> ${result.design_name}</p>
            <p><strong>Total:</strong> ₹${result.total_price}</p>
            <p><strong>Status:</strong> <span class="status-pill">${result.status}</span></p>
        `;
    } catch (error) {
        resultBox.innerHTML = '<p class="error-text">Could not connect to backend. Please make sure Python backend is running.</p>';
    }
});
